# Auto Deface Website (ADW)

What is ADW?<br>
Auto Deface Website (ADW) is a tool inspired by the WebDav tool and this tool can hacking 3600+ websites that have been targeted, but keep in mind that it's not easy.
**screnshoot:**
![1](https://raw.githubusercontent.com/wanzxploit/deface/main/adw.png)

**how to install tols:**

**Termux:**
* `pkg install python`
* `pkg install python2`
* `pip2 install requests`
* `pkg install git`
* `git clone https://github.com/wanzxploit/deface`
* `cd deface`
* `python2 adw.py`

**Linux:**
* `apt-get install python`
* `apt-get install pthon-pip`
* `pip install requests`
* `apt-get install git`
* `git clone https://github.com/wanzxploit/deface`
* `cd deface`
* `python adw.py`

**NOTE:** This script or tool is in the development stage to a tool version that will be named HackWeb, and this project is developed by Wanz Xploit.


[YOUTUBE](https://www.youtube.com/c/WanzXploit) <br>
[WHATSAPP](https://wa.me/+62881037302039)
